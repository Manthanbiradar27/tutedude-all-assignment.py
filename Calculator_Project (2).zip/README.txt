=====================================
   CALCULATOR USING TKINTER (PYTHON)
=====================================

👨‍💻 Project Information:
This project is a simple GUI calculator built using Python's Tkinter library.  
It supports basic arithmetic operations like addition, subtraction, multiplication, and division.  

----------------------
📌 How to Run the Code
----------------------
1. Open a terminal/command prompt.
2. Navigate to the folder containing "calculator.py".
3. Run the program with:
   python calculator.py
4. The Calculator window will open.

----------------------
🧮 Features
----------------------
✔️ Addition (+)  
✔️ Subtraction (-)  
✔️ Multiplication (*)  
✔️ Division (/)  
✔️ Clear Button (C) to reset  
✔️ Equal Button (=) to show result  

----------------------
📌 Submission Steps
----------------------
1. Keep "calculator.py" and this "README.txt" in a folder named "Calculator_Project".
2. Right-click the folder and select:
   Send to → Compressed (zipped) folder
   (This will create "Calculator_Project.zip")
3. Upload the zip file to Google Drive.
4. Right-click → Get Link → Change access to "Anyone with the link".
5. Submit the generated link.

----------------------
✅ Done!
----------------------

🎉 Project is ready for submission!
